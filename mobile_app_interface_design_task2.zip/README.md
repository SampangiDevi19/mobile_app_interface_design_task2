# Mobile App Interface Design (Task 2)

Objective:
Design a modern mobile application interface using Figma or a similar UI tool.

Screens:
1. Splash Screen
2. Login Screen
3. Home Screen
4. Product Details
5. Profile

Design Principles:
- Consistent spacing
- Simple navigation
- Modern typography
- Rounded cards and buttons
- Minimal color palette

No coding is required. This project focuses on UI/UX design and interaction flow.
